﻿#include "DxLib.h"

namespace
{
    constexpr int kScreenWidth  = 1280;
    constexpr int kScreenHeight = 720;
    constexpr int kColorBit     = 32;
}

int WINAPI WinMain(_In_ HINSTANCE, _In_opt_ HINSTANCE, _In_ LPSTR, _In_ int)
{
    // ログファイル(Log.txt)を出力しない
    SetOutApplicationLogValidFlag(FALSE);

    // ウィンドウモード / 画面サイズ / タイトル
    ChangeWindowMode(TRUE);
    SetGraphMode(kScreenWidth, kScreenHeight, kColorBit);
    SetMainWindowText("$projectname$");

    // 非アクティブ時も処理を続ける
    SetAlwaysRunFlag(TRUE);

    if (DxLib_Init() == -1)
    {
        return -1;
    }

    // 描画先を裏画面に設定(ダブルバッファ)
    SetDrawScreen(DX_SCREEN_BACK);

    // ===== 初期化処理 =====


    // ===== メインループ =====
    while (ProcessMessage() == 0 && CheckHitKey(KEY_INPUT_ESCAPE) == 0)
    {
        ClearDrawScreen();

        // ----- 更新処理 -----


        // ----- 描画処理 -----
        // 画面中央に四角を描画 (左上x, 左上y, 右下x, 右下y, 色, 塗りつぶし)
        constexpr int kBoxSize = 200;
        const int left = (kScreenWidth  - kBoxSize) / 2;
        const int top  = (kScreenHeight - kBoxSize) / 2;
        DrawBox(left, top, left + kBoxSize, top + kBoxSize, GetColor(0, 160, 255), TRUE);

        DrawString(10, 10, "ESCで終了", GetColor(255, 255, 255));

        // 裏画面を表画面に反映(垂直同期待ち)
        ScreenFlip();
    }

    // ===== 終了処理 =====
    DxLib_End();

    return 0;
}
